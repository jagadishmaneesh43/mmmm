package com.movieplan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMovieTicketSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
